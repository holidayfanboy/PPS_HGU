#include <iostream>
using namespace std;

int main()
{
    int N = 0;
    cin >> N;

    if (N%2 == 0)
    {
        cout << "SK";
    }
    else
    {
        cout << "CY";
    }

    return 0;
}