#include <iostream>
using namespace std;

int main() 
{
    int y = 0;
    cin >> y;
    cout << y - 543;
    return 0;
}